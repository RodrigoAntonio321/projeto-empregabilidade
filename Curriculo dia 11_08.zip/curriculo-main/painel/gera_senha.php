<?php

    $valor = "4321";

    $senha_cripto = md5($valor);

    echo $senha_cripto;




?>