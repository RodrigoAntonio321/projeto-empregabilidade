# curriculo
Projeto Interdisciplinar com CRUD de Currículos

Projeto sendo desenvolvido pelos alunos do 2ºC de Técnico em Informática para Internet

#Tecnologias envolvidas:

- PHP
- MySQL
- JavaScript


DER - Banco de Dados:
![image](https://user-images.githubusercontent.com/53703505/184639009-602d16d7-3fe8-4cfd-adc5-ac9abfb30794.png)
